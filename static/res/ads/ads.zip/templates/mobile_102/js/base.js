
$(function(){
	
	//burger
	var h=$(window).height(); 
	
	$(".QZburger").css("height",h-50+"px")
	
	var x=true;
	
	$("#QZhead .meun").click(function(){
		var Htop=$("body").scrollTop();
		if(x){
			$(".QZburger").slideDown();
			document.body.scrollTop=Htop;
			$("#Wrap").css({"height":h+"px","overflow":"hidden"});//使网页不可滚动
			
			
			if($('#cambrian0').size()>=1){
				$('#QZhead').css({'position':'fixed','top':'65px'})
				$('.QZburger').css({'position':'fixed','top':'115px'})
			}else{
				$('#QZhead').css({'position':'fixed','top':'0'})
				//$('#QZburger').css({'position':'fixed','top':'0'})
			}
			
			var MtOP = $('.QZburger').next('div').css('margin-top');
			
			if(MtOP=='6px'){
				$('.QZburger').next('div').css('margin-top','57px')
			}else{
				$('.QZburger').next('div').css('margin-top','51px')
			}
			x= false;
		}else{
			$(".QZburger").slideUp();
			document.body.scrollTop=Htop;
			$("#Wrap").css({"overflow":"initial"});//使网页恢复滚动
			$('#QZhead').css({'position':'relative','top':'0'})
			$('.QZburger').next('div').css('margin-top','')
			x= true;
		}
	})
	$(".QZburger .closebtn").click(function(){
		var Htop=$("body").scrollTop();
		
		$(".QZburger").slideUp();
		document.body.scrollTop=Htop;
		$('#Wrap').css({"overflow":"initial"});//使网页恢复滚动
		$('#QZhead').css({'position':'relative','top':'0'})
		$('.QZburger').next('div').css('margin-top','')
		x= true;

	})
	
	//up
	 $(window).scroll(function() {
	        var scroll_len = $(window).scrollTop();
	        if(scroll_len > 120) {
	            $('.QZ-up').fadeIn();
	        } else {
	            $('.QZ-up').fadeOut();
	        };
	    });
	$('.QZ-up').click(function(e){
		$("body,html").animate({scrollTop:0},300);
	})

	//PAGE
	$(".page>span .cbtn").css("display","none");
	$(".page>span").click(function(){

		$(this).children("div").show();
	})
	$(document).click(function(){
		$(".page>span .cbtn").css("display","none");
	})
	$(".page>span .cbtn,.page>span").click(function(event){
		event.stopPropagation();
	});

		//pagea
	$(".pagea>span .cbtn").css("display","none");
	$(".pagea>span").click(function(){

		$(this).children("div").show();
	})
	$(document).click(function(){
		$(".pagea>span .cbtn").css("display","none");
	})
	$(".pagea>span .cbtn,.pagea>span").click(function(event){
		event.stopPropagation();
	});

	
	//meun
	var num=$(".menu li").length;
	var j=0; 
	var p=null; 
	var l=$(window).width(); //屏幕宽度
	var b=null; 
	
	b=$(".menu li").eq(num-1).width()+30; //最后一个a的长度
	for(var i=0;i<num;i++){
		j=j+$(".menu li").eq(i).width()+30;
	};
	$(".menu ul").css("width",j+1+"px");//ul的长度
    var obj=$(".current");
    
    if(obj.html()){
    	p=obj.offset().left;
    }
	if(j>l){
		if(p<=j&&p>l-90){
			var e=p-l/2;
			var f=l/2-b;
			var z=j-l+12;
			
			if(e<f){
				l2=l/2;
				$(".menu").scrollLeft(l2);	
			}else{
				$(".menu").scrollLeft(z);
			}
		}
	}
	
	//	游戏专区
	if($('.swiper-gamezq').size()>=1){
		var swiperzq = new Swiper('.swiper-gamezq', {
	        pagination: '.swiper-pagination',
	        slidesPerView:'auto',
	        spaceBetween:6,
	    	freeMode: true
	    });
	    $('.swiper-gamezq .swiper-slide').css('width','144px')
	    swiperzq.update()
	}
	
//	//软件游戏详情
//	
//	$('.cont4 .cont4-lis .lis').eq(0).show();
//	$('.cont4 .tabtop p').click(function(){
//		$(this).addClass('on').siblings('p').removeClass('on');
//		$('.cont4 .cont4-lis .lis').hide().eq($(this).index()).show();
//	})
	
	
	
})



$(function(){
	//首页幻灯 软件专题幻灯
	if($('.swipe-hd').size()>=1){
		var Swiperhd = new Swiper ('.swiper-container', {
			pagination: '.swiper-pagination',
			paginationClickable: '.swiper-pagination',
			//paginationClickable :true,
		    loop: true,
		    autoplay : 5000,
		    onSlideChangeStart: function (swiper) {
	
		      var index = swiper.realIndex;
		      
		       $('.swipe-hd .swiper-pagination span').eq(index).addClass('swiper-pagination-bullet-active').siblings().removeClass('swiper-pagination-bullet-active');
	
		    }
		    
		  })
		
		
	}
})

//收起展开
function lishide(){
	$('.Toplist ul li').hide()
	for (k=0;k<7;k++) {
		$('.Toplist ul li').eq(k).show();
	}
	$('.Toplist ul li.mor').show()
}
lishide()
var showtab = false
$('.Toplist ul li.mor').click(function(){
	if(showtab==false){
		$('.Toplist ul li').show()
		$(this).find('a').html('--收起');
		showtab=true
	}else{
		lishide()
		$(this).find('a').html('--展开');
		showtab=false
	}
})


$(function(){
	//软件游戏首页 搜索 切换
	$('.S_soft .soft_lis').eq(0).show();
	$('.S_soft .searchlis').eq(0).show();

	$('.S_soft .S_softtop p').click(function(){
		$(this).addClass('on').siblings().removeClass('on');
		$('.S_soft .soft_lis').eq($(this).index()).show().siblings('.soft_lis').hide()
		$('.S_soft .searchlis').eq($(this).index()).show().siblings('.searchlis').hide()
	})
})


nowPage=2;
var addMoreUrl ="/Home/Ajax/getMoreArticle";
//加载更多游戏，软件
function addMore(cateid,flag){
	$.ajax({
		type:"post",
		url:addMoreUrl,
		data:{cateid:cateid,pageSize:10,page:nowPage},
		success:function(data) {
			var html = spliceArticleHtml(data.data)
			$("#addMore").append(html);
			if(data.data.length==0){
				$("#more").html("没有更多数据");
			}
			nowPage++;
		}
	})

}
function spliceArticleHtml(dts){
	var html = "";
	if(dts.length>0){
		for (var key in dts) {
			html+='<li>';
			html+='	<a href="/show_g'+dts[key]['sid']+'.html" class="img">';
			html+='		<img src="'+dts[key]['icon']+'" alt="">';
			html+='		</a>';
			html+='		<a href="/show_g'+dts[key]['sid']+'.html" class="downl">下载</a>';
			html+='		<div class="info">';
			html+='		<div>';
			html+='		<a href="/show_g'+dts[key]['sid']+'.html">'+dts[key]['title']+'</a>';
			html+='		<p class="size">   '+dts[key]['size']+'M</p>';
			html+='<p class="miaoshu">'+dts[key]['desc']+'</p>';
			html+='		</div>';
			html+='		</div>';
			html+='		</li>';
		}
	}
	return html;
}



function addDown(sid,flag,hit_day,sourceid,obj){
	var add_down_url =  "/Home/Ajax/addDownCount";
	$.ajax({
		type:"post",
		url:add_down_url,
		data:{sid:sid,hit_day:hit_day,flag:flag,sourceid:sourceid},
		success:function(data) {

		}
	});

}


function IsPhoneNum(phone){
	var validateReg = /^1\d{10}$/;
	return validateReg.test($.trim(phone));
}

var type = 0;
var cateid = 0;
function addAppointment(stype,acount,acateid){
	type = stype;
	cateid = acateid;
	//$("#peopleCount").html(acount);
	$("#peopleCount").html(0);
	$('.yymengban,.yywrap').show();

}

// 菜单
var meun = true;
$('#QZhead2 .meun').click(function(){
	if(meun){
		$('.QZburger2').slideDown();
		meun = false;
		$(this).css('background-position','0 -40px ')
	}else{
		$('.QZburger2').slideUp();
		meun = true;
		$(this).css('background-position','0 0')
	}
})
