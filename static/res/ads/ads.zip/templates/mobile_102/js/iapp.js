function hws(url) {

   iapp.fn('js.hws("'+url+'")');

}

function loadads(title,logo,url) {
var html=' ';
html += '<div class="swiper-slide">';
 
html += '<a href="https://jq.qq.com/?_wv=1027&k=5w66kER"><img src="/uploads/images/a0a1f95f12d5f936e35c2e35f591ed95.png" alt="加群1" style="width: 100%;height: 100%;" /></a>';
html += '						</div>	';							
  $(".swiper-wrapper").append(html);					
}

			